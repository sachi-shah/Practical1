
import {Component} from "react";


class Square extends Component
{
  render()
  {
    return(
        <div>
      <img src={this.props.value[0]} alt="places" height="200px" width="400px"/>
    <p>{this.props.value[1]}</p>
      
        </div>
    );
  }
}

class Board extends Component{
  renderSquareButton(value)
  {
    return <Square value={value} />;
  }
  
  render()
  {
    return(
      <div align="center" >
        {this.renderSquareButton(["https://media.istockphoto.com/photos/taj-mahal-agra-india-picture-id952763206?k=6&m=952763206&s=612x612&w=0&h=cmvVE_-LPIU-yvJUo-ci6afoxzrW6qniskwTNQZHeMA=" ,"Taj Mahal"])}
        {this.renderSquareButton(["https://media.istockphoto.com/photos/the-bandraworli-sea-link-mumbai-india-picture-id860528756?k=6&m=860528756&s=612x612&w=0&h=wzdQnJrelzNpBVPUYhlRTG0WV0sAi6MOKmlefR7ed2Y=","Mumbai"])}
        {this.renderSquareButton(["https://media.istockphoto.com/photos/church-in-panjim-picture-id184867271","Goa"])}
        
        </div>
    );
  } 
}

export default Board;


