import {Component} from "react";

class Form extends Component{
  state = {username: 'Enter github username'}

  handleSubmit = async(event) => {
    event.preventDefault();
    const axios = require('axios');
     const response = await axios.get(`https://api.github.com/users/${this.state.username}` )
     console.log(response)

  }
  render(){
    return(
      <form onSubmit={this.handleSubmit}>
        <input type="text" placeholder="Enter your name" value={this.state.username}
        onChange = {event => this.setState({username: event.target.value})}/>
        <button>Submit</button>
        
      </form>
    );
  }
}
export default Form;

